package model;

public class SPC {
    public boolean verificarClienteNegativado(Cliente cliente) {
        // Code to check if the client is listed as negative in SPC
        // Return true if the client is listed as negative, false otherwise
        return false;
    }
}
