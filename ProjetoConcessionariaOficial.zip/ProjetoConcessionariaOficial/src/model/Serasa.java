package model;

public class Serasa {
    public boolean verificarClienteNegativado(Cliente cliente) {
        // Code to check if the client is listed as negative in Serasa
        // Return true if the client is listed as negative, false otherwise
        return false;
    }
}
