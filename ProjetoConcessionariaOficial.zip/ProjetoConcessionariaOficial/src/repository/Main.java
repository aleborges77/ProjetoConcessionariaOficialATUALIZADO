package repository;

import model.*;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        exibirMensagemBoasVindas();}

        private static void exibirMensagemBoasVindas() {
            JOptionPane.showOptionDialog(null, "Bem-vindo a Premium Cars",
                    "Mensagem de Boas-vindas", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE, null, new String[]{"Entrar"}, "Entrar");
        }


        // Criando a concessionária
        Concessionaria concessionaria = new Concessionaria("Concessionária de Luxo");

        // Criando alguns carros
        Carro carro1 = new Carro("BMW", "Série 7", 2022, "Preto", 250000.00, 1);
        Carro carro2 = new Carro("Mercedes-Benz", "Classe S", 2023, "Branco", 280000.00, 2);
        Carro carro3 = new Carro("Audi", "A8", 2023, "Prata", 265000.00, 3);
        Carro carro4 = new Carro("Lamborghini", "Aventador", 2022, "Amarelo", 800000.00, 4);
        Carro carro5 = new Carro("Ferrari", "488 GTB", 2023, "Vermelho", 750000.00, 5);
        Carro carro6 = new Carro("Porsche", "911 Turbo S", 2022, "Azul", 320000.00, 6);
        Carro carro7 = new Carro("Rolls-Royce", "Phantom", 2023, "Branco", 900000.00, 7);
        Carro carro8 = new Carro("Bentley", "Continental GT", 2022, "Cinza", 400000.00, 8);

        // Criando alguns funcionários
        Funcionario funcionario1 = new Funcionario("João", "Vendedor", 5000.00);
        Funcionario funcionario2 = new Funcionario("Maria", "Gerente", 8000.00);
        Funcionario funcionario3 = new Funcionario("Pedro", "Vendedor", 4500.00);
        Funcionario funcionario4 = new Funcionario("Ana", "Vendedor", 4800.00);
        Funcionario funcionario5 = new Funcionario("Lucas", "Financeiro", 6000.00);
        Funcionario funcionario6 = new Funcionario("Juliana", "Marketing", 5500.00);
        Funcionario funcionario7 = new Funcionario("Gustavo", "Vendedor", 4700.00);
        Funcionario funcionario8 = new Funcionario("Carolina", "Vendedor", 4900.00);

        // Criando alguns clientes
        Cliente cliente1 = new Cliente("Pedro", "Rua A, 123", "123456789");
        Cliente cliente2 = new Cliente("Ana", "Rua B, 456", "987654321");
        Cliente cliente3 = new Cliente("Mariana", "Rua C, 789", "654987321");
        Cliente cliente4 = new Cliente("Rafael", "Rua D, 987", "789654321");
        Cliente cliente5 = new Cliente("Isabela", "Rua E, 654", "321456987");
        Cliente cliente6 = new Cliente("Thiago", "Rua F, 321", "987123456");
        Cliente cliente7 = new Cliente("Amanda", "Rua G, 951", "456789321");
        Cliente cliente8 = new Cliente("Gabriel", "Rua H, 159", "321789654");

        // Adicionando carros ao estoque da concessionária
        concessionaria.adicionarCarro(carro1);
        concessionaria.adicionarCarro(carro2);
        concessionaria.adicionarCarro(carro3);
        concessionaria.adicionarCarro(carro4);
        concessionaria.adicionarCarro(carro5);
        concessionaria.adicionarCarro(carro6);
        concessionaria.adicionarCarro(carro7);
        concessionaria.adicionarCarro(carro8);

        // Contratando funcionários
        concessionaria.contratarFuncionario(funcionario1);
        concessionaria.contratarFuncionario(funcionario2);
        concessionaria.contratarFuncionario(funcionario3);
        concessionaria.contratarFuncionario(funcionario4);
        concessionaria.contratarFuncionario(funcionario5);
        concessionaria.contratarFuncionario(funcionario6);
        concessionaria.contratarFuncionario(funcionario7);
        concessionaria.contratarFuncionario(funcionario8);

        // Exibindo estoque da concessionária
        concessionaria.exibirEstoque();

        // Exibindo funcionários da concessionária
        concessionaria.exibirFuncionarios();

        // Criando alguns serviços
        Servicos servico1 = new Servicos("Lavação", 50.00);
        Servicos servico2 = new Servicos("Polimento", 100.00);
        Servicos servico3 = new Servicos("Troca de óleo", 80.00);

        // Exibindo serviços disponíveis
        System.out.println("Serviços disponíveis:");
        System.out.println(servico1);
        System.out.println(servico2);
        System.out.println(servico3);

        // Criando uma instância de SPC
        SPC spc = new SPC();

        // Verificando se o cliente está negativado no SPC
        boolean cliente1Negativado = spc.verificarClienteNegativado(cliente1);
        System.out.println("Cliente 1 negativado no SPC? " + cliente1Negativado);

        // Realizando uma venda com financiamento
        MetodoPagamento metodoPagamento1 = MetodoPagamento.FINANCIAMENTO;
        concessionaria.realizarVenda(carro1, cliente1, metodoPagamento1);

        // Realizando uma venda com pagamento à vista
        MetodoPagamento metodoPagamento2 = MetodoPagamento.PAGAMENTO_A_VISTA;
        concessionaria.realizarVenda(carro2, cliente2, metodoPagamento2);

        // Exibindo estoque atualizado
        concessionaria.exibirEstoque();
    }



}
